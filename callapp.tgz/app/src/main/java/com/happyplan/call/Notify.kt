package com.happyplan.call

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat

/** 이 폰에 띄우는 경고 알림 */
object Notify {
    private const val CH = "hp_alert"

    fun recordingOff(c: Context, count: Int) {
        val nm = c.getSystemService(NotificationManager::class.java) ?: return
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CH, "녹음 경고", NotificationManager.IMPORTANCE_HIGH)
            )
        }
        val n = NotificationCompat.Builder(c, CH)
            .setSmallIcon(android.R.drawable.stat_notify_error)
            .setContentTitle("⚠️ 통화 녹음이 꺼진 것 같아요")
            .setContentText("최근 통화 ${count}건에 녹음 파일이 없습니다. 전화 앱 → 설정 → 통화 녹음 → 자동 녹음을 켜주세요.")
            .setStyle(NotificationCompat.BigTextStyle().bigText(
                "최근 통화 ${count}건에 녹음 파일이 없습니다.\n전화 앱 → 설정 → 통화 녹음 → 자동 통화 녹음 → 켜기 (모든 통화)"))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()
        runCatching { nm.notify(2, n) }
    }
}
