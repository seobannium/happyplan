package com.happyplan.call

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * 자동 업데이트: 깃허브 최신 앱을 6시간마다 확인해서 새 버전이면 미리 받아두고
 * "업데이트 준비됨" 알림을 띄운다. 안드로이드 규칙상 설치 확인 버튼 1번은 사람이 눌러야 함.
 */
object Updater {
    private const val TAG = "HPUpd"
    private const val API = "https://api.github.com/repos/seobannium/happyplan/releases/tags/app-latest"
    private const val CH = "hp_update"

    private fun sp(c: Context) = c.getSharedPreferences("hp_upd", Context.MODE_PRIVATE)
    fun apkFile(c: Context) = File(c.filesDir, "update.apk")

    private fun myVersion(c: Context): Long {
        val pi = c.packageManager.getPackageInfo(c.packageName, 0)
        return if (Build.VERSION.SDK_INT >= 28) pi.longVersionCode else pi.versionCode.toLong()
    }

    /** 받아둔 새 버전 이름 (없으면 null) */
    fun readyVersion(c: Context): String? {
        val f = apkFile(c)
        if (!f.exists()) return null
        val pi = c.packageManager.getPackageArchiveInfo(f.path, 0) ?: return null
        val v = if (Build.VERSION.SDK_INT >= 28) pi.longVersionCode else pi.versionCode.toLong()
        if (pi.packageName != c.packageName || v <= myVersion(c)) { f.delete(); return null }
        return pi.versionName
    }

    /** 확인 + 다운로드. force=false면 6시간에 한 번만 */
    fun check(c: Context, force: Boolean = false): String? {
        val now = System.currentTimeMillis()
        if (!force && now - sp(c).getLong("checked", 0L) < 6 * 3600_000L) return readyVersion(c)
        sp(c).edit().putLong("checked", now).apply()
        try {
            val conn = URL(API).openConnection() as HttpURLConnection
            conn.connectTimeout = 20000; conn.readTimeout = 30000
            conn.setRequestProperty("Accept", "application/vnd.github+json")
            if (conn.responseCode != 200) return readyVersion(c)
            val j = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
            val assets = j.getJSONArray("assets")
            var url: String? = null; var stamp = ""
            for (i in 0 until assets.length()) {
                val a = assets.getJSONObject(i)
                if (a.getString("name").endsWith(".apk")) {
                    url = a.getString("browser_download_url"); stamp = a.optString("updated_at")
                }
            }
            if (url == null) return readyVersion(c)
            // 같은 파일이면 다시 받지 않음
            if (stamp == sp(c).getString("stamp", "") && !force) return readyVersion(c)
            val tmp = File(c.filesDir, "update.tmp")
            val d = URL(url).openConnection() as HttpURLConnection
            d.connectTimeout = 20000; d.readTimeout = 120000; d.instanceFollowRedirects = true
            if (d.responseCode != 200) return readyVersion(c)
            d.inputStream.use { inp -> tmp.outputStream().use { inp.copyTo(it) } }
            tmp.renameTo(apkFile(c))
            sp(c).edit().putString("stamp", stamp).apply()
        } catch (e: Exception) { Log.w(TAG, "check $e") }
        val v = readyVersion(c)
        if (v != null) notifyReady(c, v)
        return v
    }

    private fun notifyReady(c: Context, ver: String) {
        val nm = c.getSystemService(NotificationManager::class.java) ?: return
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CH, "앱 업데이트", NotificationManager.IMPORTANCE_HIGH))
        }
        val open = Intent(c, MainActivity::class.java).putExtra("install", true)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val pi = PendingIntent.getActivity(c, 7, open,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(c, CH)
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle("해피플랜 콜 업데이트 준비됨 (v$ver)")
            .setContentText("눌러서 '업데이트'만 누르면 끝")
            .setContentIntent(pi).setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
        runCatching { nm.notify(7, n) }
    }

    /** 화면이 떠 있을 때 호출: 설치 확인창을 띄움 */
    fun install(c: Context): Boolean {
        if (readyVersion(c) == null) return false
        return try {
            val pi = c.packageManager.packageInstaller
            val params = PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL)
            if (Build.VERSION.SDK_INT >= 31) {
                params.setRequireUserAction(PackageInstaller.SessionParams.USER_ACTION_NOT_REQUIRED)
            }
            val id = pi.createSession(params)
            pi.openSession(id).use { s ->
                apkFile(c).inputStream().use { inp ->
                    s.openWrite("app.apk", 0, apkFile(c).length()).use { out ->
                        inp.copyTo(out); s.fsync(out)
                    }
                }
                val cb = Intent(c, InstallResult::class.java)
                val flags = PendingIntent.FLAG_UPDATE_CURRENT or
                        (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
                s.commit(PendingIntent.getBroadcast(c, 8, cb, flags).intentSender)
            }
            true
        } catch (e: Exception) { Log.w(TAG, "install $e"); false }
    }
}

/** 설치 결과: 사용자 확인이 필요하면 확인창을 띄움 */
class InstallResult : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        when (i.getIntExtra(PackageInstaller.EXTRA_STATUS, -999)) {
            PackageInstaller.STATUS_PENDING_USER_ACTION -> {
                @Suppress("DEPRECATION")
                val confirm = i.getParcelableExtra<Intent>(Intent.EXTRA_INTENT) ?: return
                confirm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                runCatching { c.startActivity(confirm) }
            }
            PackageInstaller.STATUS_SUCCESS -> Updater.apkFile(c).delete()
        }
    }
}
