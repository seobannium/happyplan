package com.happyplan.call

import android.content.Context
import android.net.Uri
import android.os.Environment
import android.provider.CallLog
import android.provider.ContactsContract
import android.provider.Telephony
import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** 통화기록 / 문자 / 녹음파일을 읽어 서버로 보내는 핵심 로직 */
object Scanner {
    private const val TAG = "HPScan"

    fun contactName(c: Context, number: String?): String? {
        if (number.isNullOrBlank()) return null
        return try {
            val uri = Uri.withAppendedPath(
                ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number)
            )
            c.contentResolver.query(
                uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null
            )?.use { if (it.moveToFirst()) it.getString(0) else null }
        } catch (e: Exception) { null }
    }

    /** 새 통화기록을 수집해 전송. 전송한 건수 반환 */
    fun syncCalls(c: Context): Int {
        val last = maxOf(Prefs.lastCall(c), Prefs.since(c))
        val events = JSONArray()
        var newest = last
        try {
            c.contentResolver.query(
                CallLog.Calls.CONTENT_URI,
                arrayOf(
                    CallLog.Calls._ID, CallLog.Calls.NUMBER, CallLog.Calls.DATE,
                    CallLog.Calls.DURATION, CallLog.Calls.TYPE, CallLog.Calls.CACHED_NAME
                ),
                "${CallLog.Calls.DATE} > ?", arrayOf(last.toString()),
                "${CallLog.Calls.DATE} DESC"
            )?.use { cur ->
                val iId = cur.getColumnIndexOrThrow(CallLog.Calls._ID)
                val iNum = cur.getColumnIndexOrThrow(CallLog.Calls.NUMBER)
                val iDate = cur.getColumnIndexOrThrow(CallLog.Calls.DATE)
                val iDur = cur.getColumnIndexOrThrow(CallLog.Calls.DURATION)
                val iType = cur.getColumnIndexOrThrow(CallLog.Calls.TYPE)
                val iName = cur.getColumnIndexOrThrow(CallLog.Calls.CACHED_NAME)
                while (cur.moveToNext()) {
                    val date = cur.getLong(iDate)
                    if (date > newest) newest = date
                    val type = cur.getInt(iType)
                    val dir = when (type) {
                        CallLog.Calls.INCOMING_TYPE -> "in"
                        CallLog.Calls.OUTGOING_TYPE -> "out"
                        CallLog.Calls.MISSED_TYPE -> "missed"
                        CallLog.Calls.REJECTED_TYPE -> "rejected"
                        else -> "missed"
                    }
                    val num = cur.getString(iNum) ?: ""
                    val nm = cur.getString(iName) ?: contactName(c, num)
                    events.put(JSONObject().apply {
                        put("id", "call-" + cur.getLong(iId))
                        put("type", "call")
                        put("ts", date)
                        put("number", num)
                        put("dir", dir)
                        put("dur", cur.getLong(iDur))
                        if (nm != null) put("name", nm)
                    })
                }
            }
        } catch (e: Exception) { Log.w(TAG, "syncCalls $e"); return 0 }

        if (events.length() == 0) return 0
        if (Net.postEvents(c, events)) {
            Prefs.setLastCall(c, newest)
            return events.length()
        }
        return 0
    }

    /** 새 문자(수신)를 수집해 전송 */
    fun syncSms(c: Context): Int {
        val last = maxOf(Prefs.lastSms(c), Prefs.since(c))
        val events = JSONArray()
        var newest = last
        try {
            c.contentResolver.query(
                Telephony.Sms.Inbox.CONTENT_URI,
                arrayOf(Telephony.Sms._ID, Telephony.Sms.ADDRESS, Telephony.Sms.BODY, Telephony.Sms.DATE),
                "${Telephony.Sms.DATE} > ?", arrayOf(last.toString()),
                "${Telephony.Sms.DATE} DESC"
            )?.use { cur ->
                val iId = cur.getColumnIndexOrThrow(Telephony.Sms._ID)
                val iAddr = cur.getColumnIndexOrThrow(Telephony.Sms.ADDRESS)
                val iBody = cur.getColumnIndexOrThrow(Telephony.Sms.BODY)
                val iDate = cur.getColumnIndexOrThrow(Telephony.Sms.DATE)
                while (cur.moveToNext()) {
                    val date = cur.getLong(iDate)
                    if (date > newest) newest = date
                    val addr = cur.getString(iAddr) ?: ""
                    events.put(JSONObject().apply {
                        put("id", "sms-" + cur.getLong(iId))
                        put("type", "sms")
                        put("ts", date)
                        put("number", addr)
                        put("body", cur.getString(iBody) ?: "")
                        contactName(c, addr)?.let { put("name", it) }
                    })
                }
            }
        } catch (e: Exception) { Log.w(TAG, "syncSms $e"); return 0 }

        if (events.length() == 0) return 0
        if (Net.postEvents(c, events)) {
            Prefs.setLastSms(c, newest)
            return events.length()
        }
        return 0
    }

    private val recDirs = listOf(
        "Recordings/Call", "Call", "Sounds", "Recordings"
    )

    fun findRecordings(): List<File> {
        val root = Environment.getExternalStorageDirectory()
        val out = ArrayList<File>()
        for (d in recDirs) {
            val dir = File(root, d)
            if (dir.isDirectory) {
                dir.listFiles { f -> f.isFile && (f.name.endsWith(".m4a", true) ||
                        f.name.endsWith(".mp3", true) || f.name.endsWith(".amr", true)) }
                    ?.let { out.addAll(it.toList()) }
            }
        }
        return out.distinctBy { it.name }.sortedByDescending { it.lastModified() }
    }

    /** 아직 서버에 없는 녹음 파일 업로드. 올린 건수 반환 */
    fun syncRecordings(c: Context, maxUpload: Int = 10): Int {
        val since = Prefs.since(c)
        val files = findRecordings().filter { it.lastModified() >= since }.take(60)
        if (files.isEmpty()) return 0
        val local = Prefs.uploaded(c).toMutableSet()
        val todo = files.filter { it.name !in local }
        if (todo.isEmpty()) return 0
        // 서버에 이미 있는 건 로컬 목록에 추가하고 건너뜀
        val already = Net.have(c, todo.map { it.name }) ?: return 0
        local.addAll(already)
        var done = 0
        for (f in todo) {
            if (done >= maxUpload) break
            if (f.name in local) continue
            // 아직 녹음 중일 수 있는 파일(10초 이내 수정)은 다음 번에
            if (System.currentTimeMillis() - f.lastModified() < 10_000) continue
            if (f.length() == 0L || f.length() > 20_000_000L) { local.add(f.name); continue }
            val bytes = try { f.readBytes() } catch (e: Exception) { continue }
            if (Net.upload(c, f.name, bytes, f.lastModified())) { done++; local.add(f.name) }
        }
        Prefs.setUploaded(c, local)
        return done
    }

    @Synchronized
    fun syncAll(c: Context): String {
        if (!Prefs.configured(c)) return "서버 미설정"
        val a = syncCalls(c)
        val b = syncSms(c)
        val r = syncRecordings(c)
        val res = "통화 $a · 문자 $b · 녹음 $r"
        Prefs.setLastResult(c, java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.KOREA).format(java.util.Date()) + " " + res)
        return res
    }
}
