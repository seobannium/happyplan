package com.happyplan.call

import android.content.Context
import android.net.Uri
import android.os.Environment
import android.provider.CallLog
import android.provider.ContactsContract
import android.provider.Telephony
import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** 통화기록 / 문자 / 녹음파일을 읽어 서버로 보내는 핵심 로직 */
object Scanner {
    private const val TAG = "HPScan"

    fun contactName(c: Context, number: String?): String? {
        if (number.isNullOrBlank()) return null
        return try {
            val uri = Uri.withAppendedPath(
                ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number)
            )
            c.contentResolver.query(
                uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null
            )?.use { if (it.moveToFirst()) it.getString(0) else null }
        } catch (e: Exception) { null }
    }

    // 통화 대기·동시 수신처럼 기록 순서가 뒤바뀌는 경우를 위해 6시간 전부터 다시 훑고, 이미 보낸 id는 건너뜀
    private const val LOOKBACK = 6L * 3600_000

    /** 새 통화기록을 수집해 전송. 전송한 건수 반환 */
    fun syncCalls(c: Context): Int {
        val since = Prefs.since(c)
        val from = maxOf(since, Prefs.lastCall(c) - LOOKBACK)
        val sent = Prefs.sent(c)
        val events = JSONArray()
        var newest = Prefs.lastCall(c)
        try {
            c.contentResolver.query(
                CallLog.Calls.CONTENT_URI,
                arrayOf(
                    CallLog.Calls._ID, CallLog.Calls.NUMBER, CallLog.Calls.DATE,
                    CallLog.Calls.DURATION, CallLog.Calls.TYPE, CallLog.Calls.CACHED_NAME
                ),
                "${CallLog.Calls.DATE} > ?", arrayOf(from.toString()),
                "${CallLog.Calls.DATE} DESC"
            )?.use { cur ->
                val iId = cur.getColumnIndexOrThrow(CallLog.Calls._ID)
                val iNum = cur.getColumnIndexOrThrow(CallLog.Calls.NUMBER)
                val iDate = cur.getColumnIndexOrThrow(CallLog.Calls.DATE)
                val iDur = cur.getColumnIndexOrThrow(CallLog.Calls.DURATION)
                val iType = cur.getColumnIndexOrThrow(CallLog.Calls.TYPE)
                val iName = cur.getColumnIndexOrThrow(CallLog.Calls.CACHED_NAME)
                while (cur.moveToNext()) {
                    val id = "call-" + cur.getLong(iId)
                    val date = cur.getLong(iDate)
                    if (date > newest) newest = date
                    if (id in sent || date < since) continue
                    val dir = when (cur.getInt(iType)) {
                        CallLog.Calls.INCOMING_TYPE -> "in"
                        CallLog.Calls.OUTGOING_TYPE -> "out"
                        CallLog.Calls.MISSED_TYPE -> "missed"
                        CallLog.Calls.REJECTED_TYPE -> "rejected"
                        CallLog.Calls.BLOCKED_TYPE -> "blocked"
                        else -> "missed"
                    }
                    val num = cur.getString(iNum) ?: ""
                    val nm = cur.getString(iName) ?: contactName(c, num)
                    events.put(JSONObject().apply {
                        put("id", id)
                        put("type", "call")
                        put("ts", date)
                        put("number", num)
                        put("dir", dir)
                        put("dur", cur.getLong(iDur))
                        if (nm != null) put("name", nm)
                    })
                }
            }
        } catch (e: Exception) { Log.w(TAG, "syncCalls $e"); return 0 }

        if (events.length() == 0) { if (newest > Prefs.lastCall(c)) Prefs.setLastCall(c, newest); return 0 }
        if (Net.postEvents(c, events)) {
            Prefs.setLastCall(c, newest)
            Prefs.addSent(c, idsOf(events))
            // 녹음 감시 대상: 5초 이상 실제로 통화한 건
            val watch = Prefs.watch(c).toMutableSet()
            for (i in 0 until events.length()) {
                val e = events.getJSONObject(i)
                if (e.optLong("dur") >= 5) {
                    watch.add(e.getString("id") + "|" + e.getLong("ts") + "|" +
                            e.getLong("dur") + "|" + e.optString("number"))
                }
            }
            Prefs.setWatch(c, watch)
            return events.length()
        }
        return 0
    }

    private fun idsOf(events: JSONArray): Map<String, Long> {
        val m = HashMap<String, Long>()
        for (i in 0 until events.length()) {
            val e = events.getJSONObject(i)
            m[e.getString("id")] = e.optLong("ts")
        }
        return m
    }

    /** 문자(받은·보낸) + 장문/사진 문자(MMS)를 수집해 전송 */
    fun syncSms(c: Context): Int {
        val since = Prefs.since(c)
        val from = maxOf(since, Prefs.lastSms(c) - LOOKBACK)
        val sent = Prefs.sent(c)
        val events = JSONArray()
        var newest = Prefs.lastSms(c)

        // 1) 단문 SMS
        try {
            c.contentResolver.query(
                Telephony.Sms.CONTENT_URI,
                arrayOf(Telephony.Sms._ID, Telephony.Sms.ADDRESS, Telephony.Sms.BODY,
                    Telephony.Sms.DATE, Telephony.Sms.TYPE),
                "${Telephony.Sms.DATE} > ? AND ${Telephony.Sms.TYPE} IN (1,2)", arrayOf(from.toString()),
                "${Telephony.Sms.DATE} DESC"
            )?.use { cur ->
                while (cur.moveToNext()) {
                    val id = "sms-" + cur.getLong(0)
                    val date = cur.getLong(3)
                    if (date > newest) newest = date
                    if (id in sent || date < since) continue
                    val addr = cur.getString(1) ?: ""
                    events.put(JSONObject().apply {
                        put("id", id)
                        put("type", "sms")
                        put("ts", date)
                        put("number", addr)
                        put("dir", if (cur.getInt(4) == 2) "out" else "in")
                        put("body", cur.getString(2) ?: "")
                        contactName(c, addr)?.let { put("name", it) }
                    })
                }
            }
        } catch (e: Exception) { Log.w(TAG, "sms $e") }

        // 2) 장문(LMS)·사진(MMS): 한국에서는 긴 문자가 MMS로 들어옴
        try {
            c.contentResolver.query(
                Uri.parse("content://mms"),
                arrayOf("_id", "date", "msg_box", "sub"),
                "date > ? AND msg_box IN (1,2)", arrayOf((from / 1000).toString()),
                "date DESC"
            )?.use { cur ->
                while (cur.moveToNext()) {
                    val mid = cur.getLong(0)
                    val id = "mms-$mid"
                    val date = cur.getLong(1) * 1000
                    if (date > newest) newest = date
                    if (id in sent || date < since) continue
                    val out = cur.getInt(2) == 2
                    val addr = mmsAddr(c, mid, out)
                    var body = mmsText(c, mid)
                    val sub = cur.getString(3)
                    if (!sub.isNullOrBlank() && !body.startsWith(sub)) body = "[$sub] $body"
                    events.put(JSONObject().apply {
                        put("id", id)
                        put("type", "sms")
                        put("ts", date)
                        put("number", addr)
                        put("dir", if (out) "out" else "in")
                        put("body", if (body.isBlank()) "(사진/첨부 문자)" else body)
                        contactName(c, addr)?.let { put("name", it) }
                    })
                }
            }
        } catch (e: Exception) { Log.w(TAG, "mms $e") }

        if (events.length() == 0) { if (newest > Prefs.lastSms(c)) Prefs.setLastSms(c, newest); return 0 }
        if (Net.postEvents(c, events)) {
            Prefs.setLastSms(c, newest)
            Prefs.addSent(c, idsOf(events))
            return events.length()
        }
        return 0
    }

    private fun mmsText(c: Context, mid: Long): String {
        val sb = StringBuilder()
        try {
            c.contentResolver.query(
                Uri.parse("content://mms/part"), arrayOf("_id", "ct", "text"),
                "mid = ?", arrayOf(mid.toString()), null
            )?.use { cur ->
                while (cur.moveToNext()) {
                    if (cur.getString(1) == "text/plain") {
                        val t = cur.getString(2)
                        if (t != null) sb.append(t) else {
                            val partId = cur.getLong(0)
                            c.contentResolver.openInputStream(Uri.parse("content://mms/part/$partId"))
                                ?.use { sb.append(it.readBytes().toString(Charsets.UTF_8)) }
                        }
                    }
                }
            }
        } catch (e: Exception) { }
        return sb.toString()
    }

    private fun mmsAddr(c: Context, mid: Long, out: Boolean): String {
        // 137 = 보낸 사람(FROM), 151 = 받는 사람(TO)
        val want = if (out) "151" else "137"
        try {
            c.contentResolver.query(
                Uri.parse("content://mms/$mid/addr"), arrayOf("address", "type"),
                null, null, null
            )?.use { cur ->
                while (cur.moveToNext()) {
                    if (cur.getString(1) == want) {
                        val a = cur.getString(0)
                        if (a != null && a != "insert-address-token") return a
                    }
                }
            }
        } catch (e: Exception) { }
        return ""
    }

    private val recDirs = listOf(
        "Recordings/Call", "Call", "Sounds", "Recordings"
    )

    fun findRecordings(): List<File> {
        val root = Environment.getExternalStorageDirectory()
        val out = ArrayList<File>()
        for (d in recDirs) {
            val dir = File(root, d)
            if (dir.isDirectory) {
                dir.listFiles { f -> f.isFile && (f.name.endsWith(".m4a", true) ||
                        f.name.endsWith(".mp3", true) || f.name.endsWith(".amr", true)) }
                    ?.let { out.addAll(it.toList()) }
            }
        }
        return out.distinctBy { it.name }.sortedByDescending { it.lastModified() }
    }

    /** 아직 서버에 없는 녹음 파일 업로드. 올린 건수 반환 */
    fun syncRecordings(c: Context, maxUpload: Int = 10): Int {
        val since = Prefs.since(c)
        val files = findRecordings().filter { it.lastModified() >= since }.take(60)
        if (files.isEmpty()) return 0
        val local = Prefs.uploaded(c).toMutableSet()
        val todo = files.filter { it.name !in local }
        if (todo.isEmpty()) return 0
        // 서버에 이미 있는 건 로컬 목록에 추가하고 건너뜀
        val already = Net.have(c, todo.map { it.name }) ?: return 0
        local.addAll(already)
        var done = 0
        for (f in todo) {
            if (done >= maxUpload) break
            if (f.name in local) continue
            // 아직 녹음 중일 수 있는 파일(10초 이내 수정)은 다음 번에
            if (System.currentTimeMillis() - f.lastModified() < 10_000) continue
            if (f.length() == 0L || f.length() > 600_000_000L) { local.add(f.name); continue }
            val ok = if (f.length() <= Net.CHUNK) {
                val bytes = try { f.readBytes() } catch (e: Exception) { continue }
                Net.upload(c, f.name, bytes, f.lastModified())
            } else {
                // 긴 통화(약 8분 이상): 여러 조각으로 나눠 이어 올리기 (중간에 끊겨도 이어서)
                Net.uploadChunked(c, f)
            }
            if (ok) { done++; local.add(f.name) }
        }
        Prefs.setUploaded(c, local)
        return done
    }

    /**
     * 녹음 감시: 통화가 끝나고 3분이 지났는데 그 시간대 녹음 파일이 없으면
     * "녹음 꺼짐" 경고를 서버(→사장님 메일)와 이 폰 알림으로 보낸다.
     */
    fun checkRecordings(c: Context): Int {
        val watch = Prefs.watch(c).toMutableSet()
        if (watch.isEmpty()) return 0
        val now = System.currentTimeMillis()
        val files = findRecordings()
        val alerts = JSONArray()
        val done = HashSet<String>()
        for (w in watch) {
            val p = w.split("|")
            if (p.size < 4) { done.add(w); continue }
            val ts = p[1].toLongOrNull() ?: 0L
            val dur = p[2].toLongOrNull() ?: 0L
            val end = ts + dur * 1000
            if (now < end + 3 * 60_000) continue // 아직 기다리는 중
            val found = files.any { it.lastModified() in (ts - 60_000)..(end + 10 * 60_000) }
            if (!found) {
                alerts.put(JSONObject().apply {
                    put("id", "alert-" + p[0])
                    put("type", "alert")
                    put("ts", end)
                    put("number", p[3])
                    put("dur", dur)
                    put("body", "통화 ${dur}초인데 녹음 파일이 없음 → 자동녹음이 꺼졌을 수 있음")
                })
            }
            done.add(w)
        }
        if (alerts.length() > 0) {
            if (!Net.postEvents(c, alerts)) return 0 // 다음에 다시 시도
            Notify.recordingOff(c, alerts.length())
        }
        watch.removeAll(done)
        Prefs.setWatch(c, watch)
        return alerts.length()
    }

    @Synchronized
    fun syncAll(c: Context): String {
        if (!Prefs.configured(c)) return "서버 미설정"
        val a = syncCalls(c)
        val b = syncSms(c)
        val r = syncRecordings(c)
        runCatching { checkRecordings(c) }
        val res = "통화 $a · 문자 $b · 녹음 $r"
        Prefs.setLastResult(c, java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.KOREA).format(java.util.Date()) + " " + res)
        return res
    }
}
