package com.happyplan.call

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters

class SyncWorker(c: Context, p: WorkerParameters) : CoroutineWorker(c, p) {
    override suspend fun doWork(): Result {
        return try {
            Scanner.syncAll(applicationContext)
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }
}

object NetInfo {
    fun describe(c: Context): String {
        return try {
            val cm = c.getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
            val n = cm.activeNetwork ?: return "오프라인"
            val cap = cm.getNetworkCapabilities(n) ?: return "오프라인"
            when {
                cap.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI) -> "WiFi"
                cap.hasTransport(android.net.NetworkCapabilities.TRANSPORT_CELLULAR) -> "데이터"
                else -> "연결됨"
            }
        } catch (e: Exception) { "?" }
    }
}
