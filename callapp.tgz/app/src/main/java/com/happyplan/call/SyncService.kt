package com.happyplan.call

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.BatteryManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

/** 상시 떠 있으면서 주기적으로 동기화 + 상태 신호 전송하는 포그라운드 서비스 */
class SyncService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var loop: kotlinx.coroutines.Job? = null
    private val CH = "hp_sync"

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm?.createNotificationChannel(
                NotificationChannel(CH, "해피플랜 콜 동기화", NotificationManager.IMPORTANCE_MIN)
            )
        }
        val n: Notification = NotificationCompat.Builder(this, CH)
            .setContentTitle("해피플랜 콜")
            .setContentText("통화·녹음 동기화 중")
            .setSmallIcon(android.R.drawable.stat_sys_upload)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else startForeground(1, n)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (loop?.isActive == true) {
            // 이미 돌고 있으면 즉시 1회만 추가 실행
            scope.launch { runCatching { Scanner.syncAll(applicationContext) } }
            return START_STICKY
        }
        loop = scope.launch {
            // 즉시 1회
            runCatching { Scanner.syncAll(applicationContext) }
            sendStatus(true)
            while (isActive) {
                delay(60_000) // 1분마다 확인 (새 것 없으면 통신 안 함)
                runCatching { Scanner.syncAll(applicationContext) }
                sendStatus(false)
                runCatching { Updater.check(applicationContext) } // 6시간마다 새 버전 확인
            }
        }
        return START_STICKY
    }

    private fun sendStatus(force: Boolean) {
        val c = applicationContext
        if (!Prefs.configured(c)) return
        // 상태 신호는 10분마다
        val now = System.currentTimeMillis()
        if (!force && now - Prefs.lastStatus(c) < 10 * 60_000) return
        Prefs.setLastStatus(c, now)
        val bm = getSystemService(BatteryManager::class.java)
        val batt = bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: -1
        val net = NetInfo.describe(c)
        val ev = JSONObject().apply {
            put("type", "status")
            put("id", "status")
            put("ts", System.currentTimeMillis())
            put("battery", batt)
            put("net", net)
            put("ver", runCatching { c.packageManager.getPackageInfo(c.packageName, 0).versionName }.getOrNull() ?: "")
        }
        Net.postEvents(c, JSONArray().put(ev))
    }

    override fun onDestroy() {
        scope.cancel()
        // 재시작 유도
        runCatching {
            val i = Intent(this, SyncService::class.java)
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        }
        super.onDestroy()
    }

    companion object {
        fun start(c: Context) {
            val i = Intent(c, SyncService::class.java)
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i) else c.startService(i)
        }
    }
}
