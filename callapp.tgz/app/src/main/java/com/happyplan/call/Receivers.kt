package com.happyplan.call

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

/** 전화 상태 변화: 통화 끝나면 잠시 뒤 스캔(녹음 파일이 생길 시간을 준다) */
class PhoneReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action != "android.intent.action.PHONE_STATE") return
        // 통화기록은 바로, 녹음은 조금 뒤 한 번 더
        Worker.kick(c, 5)
        Worker.kick(c, 90)
        runCatching { SyncService.start(c) }
    }
}

/** 문자 수신 즉시 스캔 */
class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Worker.kick(c, 2)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        runCatching { SyncService.start(c) }
        Worker.schedule(c)
    }
}

/** WorkManager: 지연 1회 실행 + 주기 백업 */
object Worker {
    fun kick(c: Context, delaySec: Long) {
        val req = OneTimeWorkRequestBuilder<SyncWorker>()
            .setInitialDelay(delaySec, TimeUnit.SECONDS)
            .build()
        WorkManager.getInstance(c)
            .enqueueUniqueWork("kick-$delaySec", ExistingWorkPolicy.REPLACE, req)
    }

    fun schedule(c: Context) {
        val req = androidx.work.PeriodicWorkRequestBuilder<SyncWorker>(15, TimeUnit.MINUTES).build()
        WorkManager.getInstance(c).enqueueUniquePeriodicWork(
            "periodic", androidx.work.ExistingPeriodicWorkPolicy.KEEP, req
        )
    }
}
