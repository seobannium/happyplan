package com.happyplan.call

import android.content.Context
import android.util.Base64
import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** 구글 Apps Script 서버와 통신 (모든 요청: POST JSON {token, action, ...}) */
object Net {
    private const val TAG = "HPNet"

    private fun post(c: Context, payload: JSONObject, timeoutMs: Int = 60000): JSONObject? {
        val base = Prefs.server(c)
        if (base.isEmpty()) return null
        payload.put("token", Prefs.token(c))
        try {
            var conn = URL(base).openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.connectTimeout = 20000
            conn.readTimeout = timeoutMs
            conn.doOutput = true
            conn.instanceFollowRedirects = true
            conn.setRequestProperty("content-type", "application/json; charset=utf-8")
            val bytes = payload.toString().toByteArray(Charsets.UTF_8)
            conn.setFixedLengthStreamingMode(bytes.size)
            conn.outputStream.use { it.write(bytes) }

            var code = conn.responseCode
            // Apps Script는 302로 결과 주소를 돌려줌 → GET으로 따라감
            var hops = 0
            while (code in 300..399 && hops < 5) {
                val loc = conn.getHeaderField("Location") ?: break
                conn.disconnect()
                conn = URL(loc).openConnection() as HttpURLConnection
                conn.connectTimeout = 20000
                conn.readTimeout = timeoutMs
                code = conn.responseCode
                hops++
            }
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val txt = stream?.bufferedReader()?.use { it.readText() } ?: ""
            conn.disconnect()
            if (code !in 200..299) { Log.w(TAG, "http $code"); return null }
            val j = JSONObject(txt)
            if (j.has("error")) { Log.w(TAG, "server error ${j.optString("error")}"); return null }
            return j
        } catch (e: Exception) {
            Log.w(TAG, "post err $e"); return null
        }
    }

    fun postEvents(c: Context, events: JSONArray): Boolean =
        post(c, JSONObject().put("action", "event").put("events", events)) != null

    fun have(c: Context, names: List<String>): Set<String>? {
        val r = post(c, JSONObject().put("action", "have").put("names", JSONArray(names))) ?: return null
        val arr = r.optJSONArray("have") ?: return emptySet()
        return (0 until arr.length()).map { arr.getString(it) }.toSet()
    }

    fun upload(c: Context, name: String, bytes: ByteArray, mtime: Long): Boolean {
        val b64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
        val r = post(
            c,
            JSONObject().put("action", "upload").put("name", name).put("mtime", mtime).put("data", b64),
            timeoutMs = 180000
        )
        return r != null && r.optBoolean("ok")
    }

    const val CHUNK = 8L * 1024 * 1024 // 8MB (256KB의 배수여야 함)

    /** 큰 파일: 서버가 구글 드라이브 이어올리기 세션을 열고, 조각을 차례로 전달 */
    fun uploadChunked(c: Context, f: java.io.File): Boolean {
        val size = f.length()
        val st = post(c, JSONObject().put("action", "upstart").put("name", f.name)
            .put("size", size).put("mtime", f.lastModified())) ?: return false
        if (st.optBoolean("dup") || st.optBoolean("done")) return true
        var offset = st.optLong("offset", 0L)
        try {
            java.io.RandomAccessFile(f, "r").use { raf ->
                while (offset < size) {
                    val n = minOf(CHUNK, size - offset).toInt()
                    val buf = ByteArray(n)
                    raf.seek(offset); raf.readFully(buf)
                    val r = post(c, JSONObject().put("action", "upchunk").put("name", f.name)
                        .put("size", size).put("offset", offset).put("mtime", f.lastModified())
                        .put("data", Base64.encodeToString(buf, Base64.NO_WRAP)), timeoutMs = 180000)
                        ?: return false // 다음 번에 서버가 알려주는 위치부터 이어서
                    if (r.optBoolean("done")) return true
                    val next = r.optLong("offset", -1L)
                    if (next <= offset) return false
                    offset = next
                }
            }
        } catch (e: Exception) { Log.w(TAG, "chunk $e"); return false }
        return false
    }

    /** 설정 확인용: 빈 이벤트로 서버 응답 확인 */
    fun ping(c: Context): Boolean = post(c, JSONObject().put("action", "event").put("events", JSONArray())) != null
}
