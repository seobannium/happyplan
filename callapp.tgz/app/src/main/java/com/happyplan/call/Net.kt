package com.happyplan.call

import android.content.Context
import android.util.Base64
import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** 구글 Apps Script 서버와 통신 (모든 요청: POST JSON {token, action, ...}) */
object Net {
    private const val TAG = "HPNet"

    private fun post(c: Context, payload: JSONObject, timeoutMs: Int = 60000): JSONObject? {
        val base = Prefs.server(c)
        if (base.isEmpty()) return null
        payload.put("token", Prefs.token(c))
        try {
            var conn = URL(base).openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.connectTimeout = 20000
            conn.readTimeout = timeoutMs
            conn.doOutput = true
            conn.instanceFollowRedirects = true
            conn.setRequestProperty("content-type", "application/json; charset=utf-8")
            val bytes = payload.toString().toByteArray(Charsets.UTF_8)
            conn.setFixedLengthStreamingMode(bytes.size)
            conn.outputStream.use { it.write(bytes) }

            var code = conn.responseCode
            // Apps Script는 302로 결과 주소를 돌려줌 → GET으로 따라감
            var hops = 0
            while (code in 300..399 && hops < 5) {
                val loc = conn.getHeaderField("Location") ?: break
                conn.disconnect()
                conn = URL(loc).openConnection() as HttpURLConnection
                conn.connectTimeout = 20000
                conn.readTimeout = timeoutMs
                code = conn.responseCode
                hops++
            }
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val txt = stream?.bufferedReader()?.use { it.readText() } ?: ""
            conn.disconnect()
            if (code !in 200..299) { Log.w(TAG, "http $code"); return null }
            val j = JSONObject(txt)
            if (j.has("error")) { Log.w(TAG, "server error ${j.optString("error")}"); return null }
            return j
        } catch (e: Exception) {
            Log.w(TAG, "post err $e"); return null
        }
    }

    fun postEvents(c: Context, events: JSONArray): Boolean =
        post(c, JSONObject().put("action", "event").put("events", events)) != null

    fun have(c: Context, names: List<String>): Set<String>? {
        val r = post(c, JSONObject().put("action", "have").put("names", JSONArray(names))) ?: return null
        val arr = r.optJSONArray("have") ?: return emptySet()
        return (0 until arr.length()).map { arr.getString(it) }.toSet()
    }

    fun upload(c: Context, name: String, bytes: ByteArray, mtime: Long): Boolean {
        val b64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
        val r = post(
            c,
            JSONObject().put("action", "upload").put("name", name).put("mtime", mtime).put("data", b64),
            timeoutMs = 180000
        )
        return r != null && r.optBoolean("ok")
    }

    /** 설정 확인용: 빈 이벤트로 서버 응답 확인 */
    fun ping(c: Context): Boolean = post(c, JSONObject().put("action", "event").put("events", JSONArray())) != null
}
