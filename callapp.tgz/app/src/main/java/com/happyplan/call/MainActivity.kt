package com.happyplan.call

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private val perms = buildList {
        add(Manifest.permission.READ_CALL_LOG)
        add(Manifest.permission.READ_PHONE_STATE)
        add(Manifest.permission.READ_CONTACTS)
        add(Manifest.permission.READ_SMS)
        add(Manifest.permission.RECEIVE_SMS)
        if (Build.VERSION.SDK_INT >= 33) {
            add(Manifest.permission.READ_MEDIA_AUDIO)
            add(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            add(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
    }.toTypedArray()

    private lateinit var status: TextView

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        setContentView(R.layout.main)
        val server = findViewById<EditText>(R.id.server)
        val token = findViewById<EditText>(R.id.token)
        status = findViewById(R.id.status)

        server.setText(Prefs.run { this@MainActivity.server })
        token.setText(Prefs.run { this@MainActivity.token })

        findViewById<Button>(R.id.save).setOnClickListener {
            Prefs.run { this@MainActivity.server = server.text.toString().trim() }
            Prefs.run { this@MainActivity.token = token.text.toString().trim() }
            Prefs.run {
                if (this@MainActivity.since == 0L) this@MainActivity.since = System.currentTimeMillis()
            }
            Toast.makeText(this, "저장됨", Toast.LENGTH_SHORT).show()
            ensurePerms()
            SyncService.start(this)
            Worker.schedule(this)
            refresh()
        }

        findViewById<Button>(R.id.perm).setOnClickListener { ensurePerms() }
        findViewById<Button>(R.id.batt).setOnClickListener { askBattery() }
        findViewById<Button>(R.id.test).setOnClickListener { runTest() }

        ensurePerms()
        refresh()
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun ensurePerms() {
        val missing = perms.filter {
            ContextCompat.checkSelfPermission(this, it) != android.content.pm.PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) ActivityCompat.requestPermissions(this, missing.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(r: Int, p: Array<out String>, g: IntArray) {
        super.onRequestPermissionsResult(r, p, g)
        refresh()
        if (Prefs.run { configured() }) SyncService.start(this)
    }

    private fun askBattery() {
        if (Build.VERSION.SDK_INT >= 23) {
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:$packageName")))
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        }
    }

    private fun runTest() {
        status.text = "테스트 전송 중..."
        CoroutineScope(Dispatchers.IO).launch {
            val ok = Net.ping(applicationContext)
            val r = if (ok) Scanner.syncAll(applicationContext) else "서버 연결 실패 (주소·암호 확인)"
            withContext(Dispatchers.Main) { status.text = (if (ok) "서버 연결 OK\n" else "") + "결과: $r" }
        }
    }

    private fun refresh() {
        val granted = perms.count {
            ContextCompat.checkSelfPermission(this, it) == android.content.pm.PackageManager.PERMISSION_GRANTED
        }
        val cfg = Prefs.run { configured() }
        val last = Prefs.run { lastResult }
        status.text = "권한 $granted/${perms.size} · 서버설정 ${if (cfg) "완료" else "필요"}" +
            (if (last.isNotEmpty()) "\n마지막 동기화: $last" else "")
    }
}
