package com.happyplan.call

import android.content.Context

object Prefs {
    private const val F = "hp"
    fun sp(c: Context) = c.getSharedPreferences(F, Context.MODE_PRIVATE)

    var Context.server: String
        get() = sp(this).getString("server", "")!!.trimEnd('/')
        set(v) { sp(this).edit().putString("server", v.trimEnd('/')).apply() }

    var Context.token: String
        get() = sp(this).getString("token", "")!!
        set(v) { sp(this).edit().putString("token", v).apply() }

    // 마지막으로 서버에 올린 통화기록 시각(ms). 이보다 새 기록만 전송.
    var Context.lastCall: Long
        get() = sp(this).getLong("lastCall", 0L)
        set(v) { sp(this).edit().putLong("lastCall", v).apply() }

    var Context.lastSms: Long
        get() = sp(this).getLong("lastSms", 0L)
        set(v) { sp(this).edit().putLong("lastSms", v).apply() }

    var Context.uploaded: Set<String>
        get() = sp(this).getStringSet("uploaded", emptySet())!!.toSet()
        set(v) { sp(this).edit().putStringSet("uploaded", v.toList().takeLast(500).toSet()).apply() }

    var Context.lastStatus: Long
        get() = sp(this).getLong("lastStatus", 0L)
        set(v) { sp(this).edit().putLong("lastStatus", v).apply() }

    var Context.lastResult: String
        get() = sp(this).getString("lastResult", "")!!
        set(v) { sp(this).edit().putString("lastResult", v).apply() }

    // 이 시각 이후 기록만 전송 (설치 전 개인 기록은 절대 안 올림)
    var Context.since: Long
        get() = sp(this).getLong("since", 0L)
        set(v) { sp(this).edit().putLong("since", v).apply() }

    fun Context.configured() = server.isNotEmpty() && token.isNotEmpty() && since > 0L
}
