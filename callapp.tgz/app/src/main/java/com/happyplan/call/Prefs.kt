package com.happyplan.call

import android.content.Context

/** 앱 설정/상태 저장. 모든 함수가 Context를 인자로 받음 (수신자 모호성 없음). */
object Prefs {
    private const val F = "hp"
    private fun sp(c: Context) = c.getSharedPreferences(F, Context.MODE_PRIVATE)

    fun server(c: Context): String = sp(c).getString("server", "")!!.trimEnd('/')
    fun setServer(c: Context, v: String) { sp(c).edit().putString("server", v.trimEnd('/')).apply() }

    fun token(c: Context): String = sp(c).getString("token", "")!!
    fun setToken(c: Context, v: String) { sp(c).edit().putString("token", v).apply() }

    // 이 시각 이후 기록만 전송 (설치 전 개인 기록은 올리지 않음)
    fun since(c: Context): Long = sp(c).getLong("since", 0L)
    fun setSince(c: Context, v: Long) { sp(c).edit().putLong("since", v).apply() }

    fun lastCall(c: Context): Long = sp(c).getLong("lastCall", 0L)
    fun setLastCall(c: Context, v: Long) { sp(c).edit().putLong("lastCall", v).apply() }

    fun lastSms(c: Context): Long = sp(c).getLong("lastSms", 0L)
    fun setLastSms(c: Context, v: Long) { sp(c).edit().putLong("lastSms", v).apply() }

    fun uploaded(c: Context): Set<String> =
        sp(c).getStringSet("uploaded", HashSet<String>())!!.toSet()
    fun setUploaded(c: Context, v: Set<String>) {
        sp(c).edit().putStringSet("uploaded", HashSet(v.toList().takeLast(500))).apply()
    }

    fun lastStatus(c: Context): Long = sp(c).getLong("lastStatus", 0L)
    fun setLastStatus(c: Context, v: Long) { sp(c).edit().putLong("lastStatus", v).apply() }

    fun lastResult(c: Context): String = sp(c).getString("lastResult", "")!!
    fun setLastResult(c: Context, v: String) { sp(c).edit().putString("lastResult", v).apply() }

    // 녹음 감시 대기 목록 ("id|ts|dur|number")
    fun watch(c: Context): Set<String> =
        sp(c).getStringSet("watch", HashSet<String>())!!.toSet()
    fun setWatch(c: Context, v: Set<String>) {
        sp(c).edit().putStringSet("watch", HashSet(v.toList().takeLast(200))).apply()
    }

    fun configured(c: Context): Boolean =
        server(c).isNotEmpty() && token(c).isNotEmpty() && since(c) > 0L
}
